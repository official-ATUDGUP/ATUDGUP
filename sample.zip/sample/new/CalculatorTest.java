package cn.edu.sysu.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import org.junit.Test;

public class CalculatorTest {

    @Test
    public void testAdd() {
        Calculator calculator = new Calculator();
        assertEquals(6, calculator.add(4, 2, 0));
    }

    @Test
    public void testSubtract() {
        Calculator calculator = new Calculator();
        assertEquals(2, calculator.subtract(4, 2));
    }

    @Test
    public void testDivide() {
        Calculator calculator = new Calculator();
        assertEquals(2.0, calculator.divide(4, 2), 0.001);
        assertThrows(ArithmeticException.class, () -> calculator.divide(4, 0));
    }

    @Test
    public void testMul() {
        Calculator calculator = new Calculator();
        assertEquals(8, calculator.mul(4, 2));
    }

    @Test
    public void testSubsome() {
        Calculator calculator = new Calculator();
        assertEquals(0, calculator.subsome(10));
    }
}
