package cn.edu.sysu.test;

import java.lang.ArithmeticException;

public abstract class Calculator {
	public int add(int a, int b, int c) {
		return a+b+c;
	}
	public int subtract(int a, int b) {
		return a-b;
	}
	public double divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException("The divisor cannot be zero");
        }
        return (double) a / b;
    }
	public int mul(int a, int b) {
		return a*b;
	}
	public short subsome(int a){
		int s = 10;
		return a-s;
	}
}