package org.jacoco.core.analysis;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class AbstractCounterTest {
	@Test
	public void testadd() {
		int ans = AbstractCounter.add(2,3);
		assertEquals(5, sum);
	}
	@Test
	public void testmul() {
		long ans = AbstractCounter.mul(2,7);
		assertEquals(14, ans);
	}
	@Test
	public void testaddsome() {
		int ans = AbstractCounter.addsome(2);
		assertEquals(12, ans);
	}
	@Test
	public void testhello() {
		String ans = AbstractCounter.hello();
		assertEquals("Hello", ans);
	}
	
}
